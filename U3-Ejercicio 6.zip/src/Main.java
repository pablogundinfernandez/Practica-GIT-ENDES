

public class Main {
    public static void main(String[] args) {

        Empleado e1 = new Empleado();
        Empleado e2 = new Empleado();
        Empleado e3 = new Empleado();
        Empleado e4 = new Empleado();
        Empleado e5 = new Empleado();


        System.out.println(e5);
    }
}