public class Empleado {

    private int numeroEmpleado;

    private static int contadorEmpleado=0;

    public Empleado(){

        contadorEmpleado++;

        numeroEmpleado = contadorEmpleado;
    }

    public String toString() {
        return "Numero de empleado: "+numeroEmpleado;
    }
}


