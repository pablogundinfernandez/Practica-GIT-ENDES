//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {


        // La tercera sentencia (Pasajero p = new Pasajero("pepe", 65.8, 1.83);) ya que al ser la variable "peso" definida como int, no sigue la estructura que contiene el propio constructor (String, int, double), haciendo que salte un error de sintaxis
        // Las demas sentencias son correctas y no dan ningun error de sintaxis
        Pasajero p = new Pasajero("pepe", 69, 1.83);

        Pasajero pasa1, pasa2;

        pasa1 = new Pasajero("Jose Luis");
        pasa2=null;
        pasa1 = pasa2;
        System.out.println(pasa1);


        // Sin importar en que linea coloquemos "pasa2=null"; el sistema imprimira "null", ya que al momento de ponerle a una variable "null" esta se destruye, al valer pasa1 igual que pasa2 le ocurrira lo mismo


        Pasajero pasa3 = new Pasajero("Alejandro", 1.75);

        System.out.println(pasa3);

        // pesara 73, ya que el objeto "pasa3" sigue el orden del constructor Pasajero (String n, double a) y dentro de este el peso ya esta definido por defecto a 73
    }
}